const JWT_SECRET = "alphabeta" ;
module.exports = {JWT_SECRET}