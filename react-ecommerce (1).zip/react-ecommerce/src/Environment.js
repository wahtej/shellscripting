const environment = {
    api:'http://localhost:3000'
}
export default environment;