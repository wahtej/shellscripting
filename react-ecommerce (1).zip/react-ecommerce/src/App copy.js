

function App() {
  return (
    <>
      <div>I am from the page</div>
    </>
  );
}

export default App;
