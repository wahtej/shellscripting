import Navbar from 'react-bootstrap/Navbar';

function Brand() {
    return (
      <>
        <Navbar.Brand href="#home">Ecommerce</Navbar.Brand>
      </>
    );
  }
  
  export default Brand;
  